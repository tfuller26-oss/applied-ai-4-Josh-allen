#!/usr/bin/env python3
"""
Skeleton Optimization Agent - Template for students to implement optimization algorithms

IMPORTANT: This is NOT an RL agent - it's a template for 
students to implement their own optimization algorithms (greedy, Hungarian, etc.)

This agent currently makes terrible decisions:
- Random staffing decisions
- No layout optimization 
- Ignores order priorities
- No intelligent assignment logic

Students should replace the naive methods with proper optimization algorithms.
"""

import numpy as np
from typing import Dict
from scipy.optimize import linear_sum_assignment
from .standardized_agents import BaselineAgent
from environment.employee import EmployeeState
from environment.warehouse_grid import CellType

class SkeletonOptimizationAgent(BaselineAgent):
    """
    Template for students to implement their own optimization algorithms.
    
    Students should replace the naive methods with:
    - Economic models for staffing decisions
    - Hungarian algorithm for order assignment  
    - Greedy search for layout optimization
    - Multi-objective optimization techniques
    """
    
    def __init__(self, env):
        super().__init__(env)
        self.name = "StudentOptimization"
        
        # Enable unlimited hiring for true economic optimization
        self.env._unlimited_hiring = True
        
        # Students can add their own state tracking here
        self.performance_metrics = []
        self.decision_history = []
        
        # Students can add algorithm parameters here
        # Example: Hungarian algorithm matrices, greedy search parameters, etc.
        self.staffing_parameters = {
            'hire_threshold_ratio': 3.0,
            'fire_threshold_ratio': 2.0,
            'profit_threshold': 0
        }
        
        # Students can implement adaptive parameters that change based on performance
        self.adaptive_optimization_enabled = False
        
    def reset(self):
        """Reset agent state - students should expand this"""
        self.action_history = []
        self.reward_history = []
        # TODO: Reset any neural network states, replay buffers, etc.
    
    def get_action(self, observation: Dict) -> Dict:
        """
        Generate action based on observation.
        Current implementation is intentionally terrible - students should improve!
        """
        
        timestep = int(observation['time'][0])
        staffing = self._get_staffing_action(timestep, observation['financial'][0])
        action = {
            'staffing_action': staffing,
            'layout_swap': self._get_naive_layout_action(timestep) if staffing == 0 else [0, 0],
            'order_assignments': self._get_order_assignments(timestep) if staffing == 0 else [0] * 20,
        }
        self.action_history.append(action.copy())
        return action

    def _get_staffing_action(self, timestep: int, profit: float) -> int:
        """Adjust staffing at intervals when the backlog can justify the cost."""
        if timestep % 80:
            return 0

        employees = self.env.employees
        workers = [employee for employee in employees if not employee.is_manager]
        pending = [order for order in self.env.order_queue.orders if order.status == 'pending']
        idle = [employee for employee in employees if employee.state == EmployeeState.IDLE]
        remaining = self.env.episode_length - timestep

        if not pending and idle and (idle[0].is_manager or len(workers) > 3):
            return 2  # The environment removes the first idle employee.
        if remaining < 160:
            return 0

        backlog_per_worker = len(pending) / max(1, len(workers))
        if len(workers) < min(7, self.env.max_employees) and (
            not workers or (backlog_per_worker >= 3 and profit > 0)
        ):
            return 4  # Medium wage balances speed with payroll cost.

        manager_missing = all(not employee.is_manager for employee in employees)
        if manager_missing and len(workers) >= 4 and len(employees) < self.env.max_employees:
            grid = self.env.warehouse_grid
            spawn = grid.spawn_zones[len(employees) % len(grid.spawn_zones)]
            if profit > remaining and self._find_layout_swap(timestep, spawn) != [0, 0]:
                return 3
        return 0

    def _get_naive_layout_action(self, current_timestep) -> list:
        """Choose the storage swap with the largest projected travel saving."""
        if current_timestep < 100 or current_timestep % 20:
            return [0, 0]

        manager = self.env._get_manager()
        if manager is None or manager.state != EmployeeState.IDLE:
            return [0, 0]

        return self._find_layout_swap(current_timestep, manager.position)

    def _find_layout_swap(self, current_timestep: int, manager_position: tuple) -> list:
        if current_timestep < 100:
            return [0, 0]

        grid = self.env.warehouse_grid
        bays = grid.truck_bay_positions or [grid.packing_station]
        storage_rows, storage_cols = np.where(grid.cell_types == CellType.STORAGE.value)
        positions = [
            (int(x), int(y)) for y, x in zip(storage_rows, storage_cols)
            if grid.can_access_storage(int(x), int(y))
        ]
        if len(positions) < 2:
            return [0, 0]

        distances = np.array([
            min(grid.manhattan_distance(position, bay) for bay in bays)
            for position in positions
        ])
        items = np.array([grid.item_grid[y, x] for x, y in positions])
        demand = np.zeros(len(positions))
        occupied = items >= 0
        # Divide each item's recorded picks among its available copies.
        copies = np.bincount(items[occupied], minlength=grid.num_item_types)
        demand[occupied] = grid.item_access_frequency[items[occupied]] / copies[items[occupied]]
        remaining = (self.env.episode_length - current_timestep) / current_timestep
        if remaining <= 0 or not demand.any():
            return [0, 0]

        # Account for both items moving, including any item displaced farther from delivery.
        distance_diff = distances[:, None] - distances
        demand_diff = demand[:, None] - demand
        benefit = distance_diff * demand_diff * remaining
        coords = np.array(positions)
        swap_distance = np.abs(coords[:, None] - coords).sum(axis=2)
        manager_distance = np.abs(coords - manager_position).sum(axis=1)
        benefit -= 2 * swap_distance + manager_distance[:, None]
        benefit[(distance_diff <= 0) | (demand_diff <= 0)] = -np.inf

        source, target = np.unravel_index(np.argmax(benefit), benefit.shape)
        if benefit[source, target] <= 0:
            return [0, 0]

        return [positions[index][1] * grid.width + positions[index][0] for index in (source, target)]

    def _get_order_assignments(self, timestep: int) -> list:
        """Match idle workers to orders using estimated net value per timestep."""
        assignments = [0] * 20
        workers = [
            (index, employee) for index, employee in enumerate(self.env.employees, 1)
            if not employee.is_manager and employee.state == EmployeeState.IDLE
        ]
        orders = [
            (index, order) for index, order in enumerate(self.env.order_queue.orders[:20])
            if order.status == 'pending' and not order.is_expired(timestep)
        ]
        if not workers or not orders:
            return assignments

        grid = self.env.warehouse_grid
        bays = grid.truck_bay_positions or [grid.packing_station]
        locations = {
            item: grid.find_item_locations(item)
            for item in {item for _, order in orders for item in order.items}
        }
        benefit = np.zeros((len(workers), len(orders)))
        for column, (_, order) in enumerate(orders):
            if not order.items or any(not locations[item] for item in order.items):
                continue
            for row, (_, worker) in enumerate(workers):
                position = worker.position
                distance = 0
                uncollected = list(order.items)
                while uncollected:
                    step, index, next_position = min(
                        (grid.manhattan_distance(position, candidate), index, candidate)
                        for index, item in enumerate(uncollected)
                        for candidate in locations[item]
                    )
                    distance += step
                    position = next_position
                    uncollected.pop(index)
                distance += min(grid.manhattan_distance(position, bay) for bay in bays)
                duration = max(1, distance / worker.base_speed_multiplier + len(order.items))
                time_left = self.env.episode_length - timestep
                if order.deadline is not None:
                    time_left = min(time_left, order.deadline - timestep)
                if duration <= time_left:
                    benefit[row, column] = max(0, order.value / duration - worker.salary_per_timestep)

        rows, columns = linear_sum_assignment(benefit, maximize=True)
        for row, column in zip(rows, columns):
            if benefit[row, column] > 0:
                assignments[orders[column][0]] = workers[row][0]
        return assignments

    def record_reward(self, reward: float):
        """
        WEEK 3 STEP 1: Reward tracking and learning - students should expand this
        
        TODO WEEK 3 STEP 1: Students should implement:
        - Proper reward tracking
        - Performance analysis
        - Adaptive parameter adjustment
        - Multi-objective optimization
        """
        self.reward_history.append(reward)
        
        # Skeleton optimization - doesn't actually learn anything useful
        if len(self.reward_history) > 10:
            # "Update" weights randomly (this doesn't actually improve performance)
            if reward > 0:
                self.staffing_weights += np.random.randn(4) * 0.01
                self.layout_weights += np.random.randn(3) * 0.01
    
    def should_update_policy(self) -> bool:
        """
        WEEK 3 STEP 2: Policy updates and adaptation - students should improve this
        
        TODO WEEK 3 STEP 2: Students should implement proper update schedules
        """
        return len(self.action_history) % 50 == 0  # Arbitrary update frequency
    
    def get_performance_metrics(self) -> Dict:
        """
        Get agent performance metrics for analysis
        Students can use this to debug their improvements
        """
        if not self.reward_history:
            return {"avg_reward": 0, "total_actions": 0}
        
        return {
            "avg_reward": np.mean(self.reward_history[-100:]),  # Last 100 rewards
            "total_actions": len(self.action_history),
            "exploration_rate": self.exploration_rate,
            "recent_performance": np.mean(self.reward_history[-10:]) if len(self.reward_history) >= 10 else 0
        }


def create_skeleton_optimization_agent(env) -> SkeletonOptimizationAgent:
    """Factory function to create skeleton Optimization agent"""
    return SkeletonOptimizationAgent(env)


# TODO: Students should implement these advanced components:

class StudentOptimizationAgent(SkeletonOptimizationAgent):
    """
    Template for students to implement their improved Optimization agent
    
    Suggested improvements:
    1. Replace random staffing with demand-based hiring
    2. Implement proper layout optimization using item frequencies
    3. Add distance-based order assignment
    4. Implement basic Q-optimization or policy gradients
    5. Add proper exploration vs exploitation balance
    """
    
    def __init__(self, env):
        super().__init__(env)
        self.name = "StudentOptimization"
        
        # TODO: Students implement these
        # self.q_table = {}
        # self.policy_network = SimpleNeuralNetwork()
        # self.experience_buffer = []
        # self.target_network = None
        
    def _get_improved_staffing_action(self, financial_state, employee_info, queue_info):
        """
        WEEK 2 STEP 1: Students implement intelligent staffing:
        - Hire when queue is growing
        - Fire when queue is empty for extended periods
        - Consider profit margins before hiring
        - Balance managers vs workers
        """
        pass
    
    def _get_improved_layout_action(self, observation):
        """
        WEEK 1 STEP 1: Students implement smart layout optimization:
        - Move frequently accessed items closer to delivery
        - Group items that are often ordered together
        - Only optimize when queue is manageable
        - Track swap effectiveness
        """
        pass
    
    def _get_improved_order_assignments(self, queue_info, employee_info):
        """
        WEEK 2 STEP 2: Students implement efficient order assignment:
        - Assign orders to closest available employees
        - Prioritize high-value or urgent orders
        - Consider employee current locations
        - Balance workload across employees
        """
        pass
    
    def learn_from_experience(self, state, action, reward, next_state, done):
        """
        WEEK 3 STEP 3: Students implement multi-objective optimization:
        - Performance trend analysis
        - Adaptive parameter tuning
        - Multi-objective trade-off handling
        - Robust optimization techniques
        """
        pass